import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { cloudVolumes, preloadCloudVolumes, sampleCloudVolume, cloudModelAt } from '../src/atmosphere/CloudVolumes.ts';

const manifest = JSON.parse(await readFile(new URL('../public/clouds/manifest.json', import.meta.url), 'utf8'));
const arrays: Uint8Array[] = [];
for (const volume of manifest.volumes) {
  const data = await readFile(new URL(`../public/clouds/${volume.file}`, import.meta.url));
  assert.equal(data.length, volume.size ** 3);
  assert.equal(createHash('sha256').update(data).digest('hex'), volume.sha256);
  assert.equal(data.filter(v => v > 0).length, volume.occupiedVoxels);
  arrays.push(new Uint8Array(data));
}
console.log('PASS imported volume integrity, dimensions and nonempty density');

const originalFetch = globalThis.fetch, originalWarn = console.warn;
globalThis.fetch = async () => new Response(new Uint8Array(4));
console.warn = () => {};
await preloadCloudVolumes();
console.warn = originalWarn;
assert.equal(cloudVolumes().ready, false);
assert.equal(cloudVolumes().textures.length, 0);
console.log('PASS corrupt volume leaves procedural fallback active without partial models');
globalThis.fetch = async url => new Response(Uint8Array.from(arrays[String(url).includes('01.bin') ? 0 : 1]).buffer);
await preloadCloudVolumes();
globalThis.fetch = originalFetch;
assert.ok(cloudVolumes().ready);

const N = 96;
for (let i = 0; i < 2; i++) {
  const bytes = arrays[i], hot = bytes.findIndex(v => v === 255);
  assert.ok(hot >= 0);
  const x = hot % N, y = Math.floor(hot / N) % N, z = Math.floor(hot / (N * N));
  assert.ok(Math.abs(sampleCloudVolume(i, (x + 0.5) / N, (y + 0.5) / N, (z + 0.5) / N) - 1) < 1e-10);
  const average = (bytes[hot] + bytes[hot + 1]) / 510;
  assert.ok(Math.abs(sampleCloudVolume(i, (x + 1) / N, (y + 0.5) / N, (z + 0.5) / N) - average) < 1e-10);
  // Padding must be empty to avoid opaque walls between repeated models.
  for (let a = 0; a < N; a++) for (let b = 0; b < N; b++) {
    for (const idx of [a + N * b, a + N * b + N * N * (N - 1), a + N * N * b,
      a + N * (N - 1) + N * N * b, N * a + N * N * b, (N - 1) + N * a + N * N * b]) assert.equal(bytes[idx], 0);
  }
}
console.log('PASS linear density filtering and transparent volume boundaries');

for (const [cx, cz] of [[0, 0], [1, 0], [0, 2], [-1, 0], [-3, 5]]) {
  const variant = Math.abs(cx * 3 + cz * 7) % 4;
  for (const [u, w] of [[0.4, 0.5], [0.65, 0.25]]) {
    let tu = u, tw = w;
    if (variant >= 2) [tu, tw] = [tw, tu];
    if (variant % 2) tu = 1 - tu;
    const expected = sampleCloudVolume(variant % 2, tu, 0.09, tw);
    assert.ok(Math.abs(cloudModelAt((cx + u) * 5400, 0.2, (cz + w) * 5400) - expected) < 1e-10);
  }
}
console.log('PASS cloud cell rotation and CPU/GPU coordinates including negative world positions');
console.log('4 cloud checks passed');
