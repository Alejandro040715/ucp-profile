import assert from 'node:assert/strict';
import { Quaternion, Vector3 } from 'three';
import { CombatSimulation, type CombatPose } from '../src/combat/CombatSimulation.ts';

const pose: CombatPose = { position: new Vector3(0, 1600, 0), quaternion: new Quaternion(),
  velocity: new Vector3(0, 0, -190), onGround: false, destroyed: false };
let count = 0;
function test(name: string, fn: () => void): void { fn(); count++; console.log(`PASS ${name}`); }
const fresh = (height = (_x: number, _z: number) => 0) => { const sim = new CombatSimulation(height); sim.reset(pose); return sim; };
const tick = (sim: CombatSimulation, seconds: number, p = pose) => { for (let t = 0; t < seconds; t += 1 / 60) sim.step(1 / 60, p); };

test('Acquisition takes time, requires facing a live target, and loses lock when turned away', () => {
  const sim = fresh(); tick(sim, 0.5); assert.ok(!sim.locked && sim.lockProgress > 0);
  tick(sim, 0.7); assert.ok(sim.locked);
  const away = { ...pose, quaternion: new Quaternion().setFromAxisAngle(new Vector3(0, 1, 0), Math.PI) };
  sim.step(1 / 60, away); assert.equal(sim.lockProgress, 0);
});
test('Terrain blocks target lock', () => {
  const sim = fresh((_x, z) => z < -500 && z > -1400 ? 2400 : 0);
  tick(sim, 2); assert.equal(sim.lockProgress, 0);
});
test('Launch safety blocks ground, destroyed aircraft and unlocked targets', () => {
  const sim = fresh(); assert.ok(sim.launch(pose));
  tick(sim, 1.2); assert.ok(sim.launch({ ...pose, onGround: true }));
  assert.ok(sim.launch({ ...pose, destroyed: true })); assert.equal(sim.missiles, 6);
});
test('A launched missile consumes one station, obeys cooldown and destroys a moving drone', () => {
  const sim = fresh(); tick(sim, 1.2);
  assert.equal(sim.launch(pose), null); assert.equal(sim.missiles, 5);
  assert.ok(sim.launch(pose)); assert.equal(sim.projectiles.length, 1);
  tick(sim, 12); assert.ok(sim.hits >= 1); assert.ok(!sim.targets[0].alive);
  assert.equal(sim.projectiles.length, 0); assert.notEqual(sim.selectedId, 0);
});
test('Gun hits use swept collision and do not require missile lock', () => {
  const sim = fresh();
  // Four rounds cross a small stationary practice target between sample points.
  const target = sim.targets[3]; target.position.set(0.45, 1600.15, -110); target.origin.copy(target.position);
  target.radius = 4;
  for (let i = 0; i < 4; i++) { sim.cannon(pose); tick(sim, 0.15); }
  assert.equal(sim.cannonAmmo, 176); assert.equal(target.alive, false); assert.equal(sim.hits, 1);
});
test('Flare bursts consume two rounds, respect cooldown and reset clears every projectile', () => {
  const sim = fresh(); assert.equal(sim.deployFlares(pose), true); assert.equal(sim.flares, 22);
  assert.equal(sim.deployFlares(pose), false); tick(sim, 0.7); assert.equal(sim.deployFlares(pose), true);
  sim.cannon(pose); sim.reset(pose);
  assert.equal(sim.projectiles.length, 0); assert.equal(sim.pending.length, 0);
  assert.equal(sim.flares, 24); assert.equal(sim.missiles, 6); assert.equal(sim.cannonAmmo, 180);
  assert.equal(sim.hits, 0); assert.ok(sim.targets.every(t => t.alive));
});
test('Expired rounds are removed and airborne targets stay above the ground', () => {
  const sim = fresh((_x, z) => z < -2600 ? 1850 : 0);
  sim.cannon(pose); tick(sim, 20);
  assert.equal(sim.projectiles.length, 0);
  for (const t of sim.targets.filter(t => t.kind === 'air')) assert.ok(t.position.y >= 2000);
});
test('All six aerial and ground objectives can be completed with one loadout', () => {
  const sim = fresh();
  for (const target of sim.targets) {
    sim.selectedId = target.id;
    const aimed = { ...pose, quaternion: new Quaternion().setFromUnitVectors(new Vector3(0, 0, -1), target.position.clone().sub(pose.position).normalize()) };
    tick(sim, 1.2, aimed); assert.ok(sim.locked, target.name);
    assert.equal(sim.launch(aimed), null, target.name);
    for (let i = 0; i < 60 * 18 && target.alive; i++) sim.step(1 / 60, aimed);
    assert.equal(target.alive, false, target.name);
  }
  assert.equal(sim.missiles, 0); assert.equal(sim.hits, 6);
  assert.equal(sim.pending.filter(e => e.type === 'complete').length, 1);
});
console.log(`${count} combat checks passed`);
