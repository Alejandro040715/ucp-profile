// CC0 JangaFX VDBs resampled to compact, Y-up density textures.
import { ClampToEdgeWrapping, Data3DTexture, LinearFilter, RedFormat, UnsignedByteType } from 'three';

const SIZE = 96;
const files = ['jangafx-cloud-01.bin', 'jangafx-cloud-03.bin'];
const data: Uint8Array[] = [];
const textures: Data3DTexture[] = [];
export function cloudVolumes() { return { textures, ready: textures.length === 2 }; }

export async function preloadCloudVolumes(): Promise<void> {
  try {
    const arrays = await Promise.all(files.map(async file => {
      const response = await fetch(`${import.meta.env?.BASE_URL ?? '/'}clouds/${file}`);
      if (!response.ok) throw new Error(`Cloud volume: ${response.status}`);
      const bytes = new Uint8Array(await response.arrayBuffer());
      if (bytes.length !== SIZE ** 3) throw new Error('Invalid cloud volume size');
      return bytes;
    }));
    for (const bytes of arrays) {
      const tex = new Data3DTexture(bytes, SIZE, SIZE, SIZE);
      tex.format = RedFormat; tex.type = UnsignedByteType;
      tex.minFilter = tex.magFilter = LinearFilter;
      tex.wrapS = tex.wrapT = tex.wrapR = ClampToEdgeWrapping;
      tex.unpackAlignment = 1; tex.generateMipmaps = false; tex.needsUpdate = true;
      data.push(bytes); textures.push(tex);
    }
  } catch (error) { console.warn('Cloud models unavailable; using procedural clouds.', error); }
}

// Match normalized WebGL linear filtering, including half-texel offsets.
export function sampleCloudVolume(index: number, u: number, v: number, w: number): number {
  const bytes = data[index];
  if (!bytes) return 0;
  const x = Math.max(0, Math.min(SIZE - 1, u * SIZE - 0.5));
  const y = Math.max(0, Math.min(SIZE - 1, v * SIZE - 0.5));
  const z = Math.max(0, Math.min(SIZE - 1, w * SIZE - 0.5));
  const ix = Math.floor(x), iy = Math.floor(y), iz = Math.floor(z);
  let value = 0;
  for (let dz = 0; dz < 2; dz++) for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 2; dx++) {
    const weight = (dx ? x - ix : 1 - x + ix) * (dy ? y - iy : 1 - y + iy) * (dz ? z - iz : 1 - z + iz);
    value += bytes[Math.min(iz + dz, SIZE - 1) * SIZE * SIZE + Math.min(iy + dy, SIZE - 1) * SIZE + Math.min(ix + dx, SIZE - 1)] * weight;
  }
  return value / 255;
}

export function cloudModelAt(x: number, h: number, z: number): number {
  const qx = x / 5400, qz = z / 5400;
  const cx = Math.floor(qx), cz = Math.floor(qz);
  let u = qx - cx, w = qz - cz;
  const variant = Math.abs(cx * 3 + cz * 7) % 4;
  if (variant >= 2) { const swap = u; u = w; w = swap; }
  if (variant % 2 === 1) u = 1 - u;
  return sampleCloudVolume(variant % 2, u, h * 0.45, w);
}

export const CLOUD_VOLUME_GLSL = /* glsl */ `
uniform highp sampler3D uCloudModelA;
uniform highp sampler3D uCloudModelB;
uniform float uCloudModelsReady;
float cloudModelAt(vec3 p, float h) {
  vec2 q = (p.xz + uWindOffset.xz) / 5400.0;
  vec2 cell = floor(q), uv = fract(q);
  float variant = mod(abs(cell.x * 3.0 + cell.y * 7.0), 4.0);
  if (variant >= 2.0) uv = uv.yx;
  if (mod(variant, 2.0) > 0.5) uv.x = 1.0 - uv.x;
  vec3 coord = vec3(uv.x, h * 0.45, uv.y);
  return mod(variant, 2.0) > 0.5 ? textureLod(uCloudModelB, coord, 0.0).r : textureLod(uCloudModelA, coord, 0.0).r;
}
`;
