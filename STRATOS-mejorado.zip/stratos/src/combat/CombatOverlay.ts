import { Vector3 } from 'three';
import type { Game } from '../core/Game.ts';
import { EARTH_RADIUS } from '../render/Globals.ts';
import type { CombatSimulation } from './CombatSimulation.ts';
import './combat.css';

export class CombatOverlay {
  private root = document.createElement('div');
  private status = document.createElement('div');
  private inventory = document.createElement('div');
  private direction = document.createElement('div');
  private aim = document.createElement('div');
  private markers: HTMLElement[] = [];
  private radar = document.createElement('canvas');
  private timer = 0;
  private lockBar = document.createElement('progress');

  constructor(private game: Game, private sim: CombatSimulation) {
    this.root.className = 'combat-overlay';
    const panel = document.createElement('div'); panel.className = 'combat-panel';
    const title = document.createElement('div'); title.className = 'combat-heading'; title.textContent = 'CAMPO DE PRÁCTICAS';
    this.status.className = 'combat-status'; this.inventory.className = 'combat-inventory';
    const hint = document.createElement('div'); hint.className = 'combat-hint';
    hint.textContent = 'Derecho apunta · Izquierdo misil · R objetivo · Supr cañón';
    this.lockBar.className = 'combat-lock'; this.lockBar.max = 1;
    this.lockBar.setAttribute('aria-label', 'Progreso de bloqueo del misil');
    panel.append(title, this.status, this.lockBar, this.inventory, hint);
    this.radar.width = this.radar.height = 170; this.radar.className = 'combat-radar';
    this.radar.setAttribute('aria-label', 'Radar de objetivos de práctica, alcance de 8 km');
    this.direction.className = 'combat-direction'; this.aim.className = 'combat-aim'; this.aim.textContent = '+';
    this.root.append(panel, this.radar, this.direction, this.aim);
    for (let i = 0; i < 6; i++) {
      const marker = document.createElement('div'); marker.className = 'combat-target';
      const frame = document.createElement('div'); frame.className = 'combat-bracket';
      const label = document.createElement('span'); marker.append(frame, label);
      this.root.append(marker); this.markers.push(marker);
    }
    game.uiRoot.append(this.root); this.root.hidden = true;
  }

  update(visible: boolean): void {
    this.root.hidden = !visible;
    if (!visible) return;
    const g = this.game, sim = this.sim, selected = sim.selected;
    const lock = sim.locked;
    const distance = selected ? g.aircraft.position.distanceTo(selected.position) : 0;
    this.status.textContent = selected ? `${selected.name} · ${(distance / 1000).toFixed(1)} km · ${lock ? 'BLOQUEADO' : `BUSCANDO ${Math.round(sim.lockProgress * 100)}%`}` : 'TODOS LOS OBJETIVOS ALCANZADOS';
    this.status.classList.toggle('locked', lock);
    this.root.classList.toggle('aiming', g.input.aiming);
    this.lockBar.value = sim.lockProgress;
    this.lockBar.classList.toggle('locked', lock);
    this.inventory.textContent = `MISILES ${sim.missiles}/6   CAÑÓN ${sim.cannonAmmo}   BENGALAS ${sim.flares}   OBJETIVOS ${sim.hits}/6`;
    const width = innerWidth, height = innerHeight;
    let selectedOnscreen = false;
    for (const t of sim.targets) {
      const marker = this.markers[t.id];
      const p = this.project(t.position);
      const onscreen = t.alive && p.z > -1 && p.z < 1 && Math.abs(p.x) < 0.92 && Math.abs(p.y) < 0.8;
      marker.hidden = !onscreen;
      if (!onscreen) continue;
      const chosen = t.id === sim.selectedId;
      if (chosen) selectedOnscreen = true;
      marker.style.transform = `translate(${(p.x * 0.5 + 0.5) * width}px, ${(-p.y * 0.5 + 0.5) * height}px)`;
      marker.classList.toggle('selected', chosen); marker.classList.toggle('locked', chosen && lock);
      marker.classList.toggle('ground', t.kind === 'ground');
      marker.lastElementChild!.textContent = `${t.name} · ${(g.aircraft.position.distanceTo(t.position) / 1000).toFixed(1)} km`;
    }
    this.direction.hidden = !selected || selectedOnscreen;
    if (selected && !selectedOnscreen) {
      const rel = selected.position.clone().sub(g.aircraft.position).applyQuaternion(g.aircraft.quaternion.clone().invert());
      this.direction.textContent = `${rel.z > 0 ? '↶ DETRÁS' : rel.x < 0 ? '← IZQUIERDA' : 'DERECHA →'} · ${selected.name} · ${(distance / 1000).toFixed(1)} km`;
    }
    const boresight = g.aircraft.position.clone().add(new Vector3(0, 0, -2000).applyQuaternion(g.aircraft.quaternion));
    const aim = this.project(boresight);
    this.aim.hidden = aim.z <= -1 || aim.z >= 1 || Math.abs(aim.x) > 1 || Math.abs(aim.y) > 1;
    this.aim.style.left = `${(aim.x * 0.5 + 0.5) * width}px`;
    this.aim.style.top = `${(-aim.y * 0.5 + 0.5) * height}px`;
    this.timer += g.frameDt;
    if (this.timer > 0.1) { this.timer = 0; this.drawRadar(); }
  }

  private project(position: Vector3): Vector3 {
    const p = position.clone(), c = this.game.camera.position;
    p.y -= ((p.x - c.x) ** 2 + (p.z - c.z) ** 2) / (2 * EARTH_RADIUS);
    return p.project(this.game.camera);
  }

  private drawRadar(): void {
    const ctx = this.radar.getContext('2d')!;
    ctx.clearRect(0, 0, 170, 170);
    ctx.fillStyle = 'rgba(5, 16, 17, .8)'; ctx.beginPath(); ctx.arc(85, 85, 77, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = 'rgba(123, 205, 168, .25)'; ctx.lineWidth = 1;
    for (const r of [38, 76]) { ctx.beginPath(); ctx.arc(85, 85, r, 0, Math.PI * 2); ctx.stroke(); }
    ctx.beginPath(); ctx.moveTo(9, 85); ctx.lineTo(161, 85); ctx.moveTo(85, 9); ctx.lineTo(85, 161); ctx.stroke();
    ctx.fillStyle = '#d6f6e1'; ctx.beginPath(); ctx.moveTo(85, 80); ctx.lineTo(81, 90); ctx.lineTo(89, 90); ctx.closePath(); ctx.fill();
    const inverse = this.game.aircraft.quaternion.clone().invert();
    for (const t of this.sim.targets) {
      if (!t.alive) continue;
      const p = t.position.clone().sub(this.game.aircraft.position).applyQuaternion(inverse);
      const r = Math.hypot(p.x, p.z);
      if (r > 8000) continue;
      const x = 85 + p.x / 8000 * 76, y = 85 + p.z / 8000 * 76;
      const selected = t.id === this.sim.selectedId;
      ctx.fillStyle = selected ? '#b8ffbc' : t.kind === 'air' ? '#e7b071' : '#db8b69';
      if (t.kind === 'ground') ctx.fillRect(x - 2.5, y - 2.5, 5, 5);
      else { ctx.beginPath(); ctx.arc(x, y, 2.7, 0, Math.PI * 2); ctx.fill(); }
      if (selected) { ctx.strokeStyle = '#b8ffbc'; ctx.strokeRect(x - 6, y - 6, 12, 12); }
    }
    ctx.font = '10px monospace'; ctx.textAlign = 'center'; ctx.fillStyle = '#a5c6b5'; ctx.fillText('8 km · AIRE / TIERRA', 85, 169);
  }
}
