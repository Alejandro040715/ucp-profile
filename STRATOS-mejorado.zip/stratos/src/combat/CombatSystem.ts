import {
  BoxGeometry, Color, ConeGeometry, CylinderGeometry, Group, Mesh, MeshBasicMaterial,
  MeshStandardMaterial, SphereGeometry, TextureLoader, TorusGeometry, Vector3,
} from 'three';
import type { Game } from '../core/Game.ts';
import { events } from '../core/EventBus.ts';
import { ParticleSystem } from '../effects/Particles.ts';
import { worldMaterial } from '../render/Materials.ts';
import { libTexture } from '../assets/TextureLibrary.ts';
import { CombatSimulation, MISSILE_STATIONS, type CombatPose, type Target } from './CombatSimulation.ts';
import { CombatOverlay } from './CombatOverlay.ts';
import type { CameraMode } from '../camera/CameraSystem.ts';

const FORWARD = new Vector3(0, 0, -1);

// Geometry and materials are shared by mounted rounds, launched rounds and drones.
export class CombatSystem {
  readonly sim: CombatSimulation;
  private targetGroups = new Map<number, Group>();
  private shotGroups = new Map<number, Group>();
  private wrecks: { position: Vector3; time: number }[] = [];
  private flareBodies: { position: Vector3; velocity: Vector3; age: number }[] = [];
  private smoke: ParticleSystem;
  private fire: ParticleSystem;
  private sparks: ParticleSystem;
  private mounted: Group[] = [];
  private overlay: CombatOverlay;
  private accumulator = 0;
  private particleClock = 0;
  private missileTemplate: Group;
  private tracerGeometry = new CylinderGeometry(0.07, 0.07, 12, 5);
  private tracerMaterial = new MeshBasicMaterial({ color: new Color(8, 4, 0.6), toneMapped: false });
  private radarDish: Mesh | null = null;
  private aimReturnMode: CameraMode | null = null;
  private silver = worldMaterial(new MeshStandardMaterial({ color: 0xb7bdba, roughness: 0.36, metalness: 0.5 }), { key: 'combat-metal' });
  private olive = worldMaterial(new MeshStandardMaterial({ color: 0x697052, roughness: 0.85,
    normalMap: libTexture('paint-chips', 'normal') }), { key: 'combat-olive' });
  private rubber = worldMaterial(new MeshStandardMaterial({ color: 0x161919, roughness: 0.96 }), { key: 'combat-rubber' });
  private orange = worldMaterial(new MeshStandardMaterial({ color: 0xdd6531, roughness: 0.7 }), { key: 'combat-drone' });

  constructor(private game: Game) {
    this.sim = new CombatSimulation((x, z) => game.env.height(x, z));
    const loader = new TextureLoader();
    const smokeTex = loader.load(new URL('fx/smoke.png', document.baseURI).href);
    const fireTex = loader.load(new URL('fx/fire.png', document.baseURI).href);
    this.smoke = new ParticleSystem({ max: 1100, additive: false, shape: 0, drag: 0.7, buoyancy: 1.2, lit: true, texture: smokeTex });
    this.fire = new ParticleSystem({ max: 420, additive: true, shape: 1, drag: 0.4, buoyancy: 2, lit: false, texture: fireTex });
    this.sparks = new ParticleSystem({ max: 250, additive: true, shape: 2, drag: 0.7, buoyancy: -9.8, lit: false });
    game.fxScene.add(this.smoke.mesh, this.fire.mesh, this.sparks.mesh);
    this.missileTemplate = this.missileModel();
    for (const station of MISSILE_STATIONS) {
      const mount = this.missileTemplate.clone();
      mount.position.copy(station);
      const pylon = new Mesh(new BoxGeometry(0.13, 0.45, 1.2), this.olive);
      pylon.position.copy(station).add(new Vector3(0, 0.35, 0.3));
      game.player.model.root.add(pylon, mount);
      this.mounted.push(mount);
    }
    this.overlay = new CombatOverlay(game, this.sim);
    this.reset();
  }

  private pose(): CombatPose {
    const ac = this.game.aircraft;
    return { position: ac.position, quaternion: ac.quaternion, velocity: ac.velocity,
      onGround: ac.gear.weightOnWheels, destroyed: ac.damage.destroyed };
  }

  reset(): void {
    this.sim.reset(this.pose());
    for (const group of this.shotGroups.values()) group.removeFromParent();
    this.shotGroups.clear(); this.wrecks.length = this.flareBodies.length = 0;
    this.smoke.clear(); this.fire.clear(); this.sparks.clear();
    this.accumulator = this.particleClock = 0;
    this.mounted.forEach(m => m.visible = true);
    for (const target of this.sim.targets) {
      let group = this.targetGroups.get(target.id);
      if (!group) {
        group = target.kind === 'air' ? this.droneModel() : this.groundModel(target);
        this.game.scene.add(group); this.targetGroups.set(target.id, group);
      }
      group.visible = true;
      group.position.copy(target.position);
    }
  }

  handleInput(): void {
    const input = this.game.input;
    if (input.pressed('targetNext')) this.sim.nextTarget();
    if (input.pressed('fireMissile')) {
      const reason = this.sim.launch(this.pose());
      if (reason) events.emit('message', { text: reason, kind: 'warn' });
    }
    if (input.pressed('flares')) {
      if (this.sim.deployFlares(this.pose())) events.emit('message', { text: 'Bengalas de práctica desplegadas', duration: 2 });
      else events.emit('message', { text: 'Bengalas disponibles en vuelo; espera entre ráfagas.', kind: 'warn', duration: 2 });
    }
    if (input.isHeld('fireCannon')) this.sim.cannon(this.pose());
  }

  updateAim(): void {
    const aiming = this.game.input.aiming;
    const camera = this.game.cameras;
    if (aiming && !camera.aiming) {
      this.aimReturnMode = camera.mode;
      camera.setMode('COCKPIT'); camera.centerView();
      let best = 0.9, candidate = this.sim.selectedId;
      const pose = this.pose(), forward = FORWARD.clone().applyQuaternion(pose.quaternion);
      for (const t of this.sim.targets) {
        if (!t.alive || pose.position.distanceTo(t.position) > 8000) continue;
        const score = forward.dot(t.position.clone().sub(pose.position).normalize());
        if (score > best) { best = score; candidate = t.id; }
      }
      if (candidate !== this.sim.selectedId) { this.sim.selectedId = candidate; this.sim.lockProgress = 0; }
    } else if (!aiming && camera.aiming) {
      if (this.aimReturnMode && camera.mode === 'COCKPIT' && !this.game.photoMode) camera.setMode(this.aimReturnMode);
      this.aimReturnMode = null;
    }
    camera.aiming = aiming;
  }

  update(dt: number): void {
    const active = this.game.ui.started && !this.game.paused && !this.game.ui.menuOpen;
    if (active) {
      this.accumulator += dt;
      while (this.accumulator >= 1 / 60) {
        this.sim.step(1 / 60, this.pose());
        this.accumulator -= 1 / 60;
      }
      this.consumeEvents();
      this.particleClock += dt;
      const puff = this.particleClock >= 1 / 30;
      if (puff) this.particleClock %= 1 / 30;
      for (const t of this.sim.targets) {
        const group = this.targetGroups.get(t.id)!;
        group.visible = t.alive;
        group.position.copy(t.position);
        if (t.kind === 'air') group.quaternion.setFromUnitVectors(FORWARD, t.velocity.clone().normalize());
      }
      if (this.radarDish) this.radarDish.rotation.y += dt * 0.7;
      this.updateShots(puff);
      for (let i = this.flareBodies.length - 1; i >= 0; i--) {
        const f = this.flareBodies[i]; f.age += dt;
        f.velocity.multiplyScalar(Math.exp(-dt * 0.6)); f.velocity.y -= dt * 9.8;
        f.position.addScaledVector(f.velocity, dt);
        if (f.age > 4 || f.position.y < this.game.env.height(f.position.x, f.position.z)) { this.flareBodies.splice(i, 1); continue; }
        if (puff) {
          this.fire.emit(f.position, new Vector3(), 2.2, 0.5, 0.18, new Color(14, 9, 2), 1);
          this.smoke.emit(f.position, new Vector3(), 1.4, 2.5, 2.6, new Color(0.7, 0.7, 0.68), 0.5);
        }
      }
      for (let i = this.wrecks.length - 1; i >= 0; i--) {
        const w = this.wrecks[i]; w.time += dt;
        if (w.time > 25) { this.wrecks.splice(i, 1); continue; }
        if (puff) {
          this.smoke.emit(w.position, new Vector3(0, 5, 0), 5, 6, 10, new Color(0.1, 0.09, 0.08), 0.8);
          if (w.time < 8) this.fire.emit(w.position, new Vector3(0, 3, 0), 4, 3, 1.4, new Color(6, 1.5, 0.2), 0.8);
        }
      }
      const wind = this.game.weather.windAt(this.game.camera.position.y, new Vector3());
      this.smoke.update(dt, wind); this.fire.update(dt, wind); this.sparks.update(dt, wind);
    }
    this.overlay.update(active);
  }

  private consumeEvents(): void {
    for (const e of this.sim.pending.splice(0)) {
      if (e.type === 'launch') {
        if (e.projectile.kind === 'missile') {
          this.mounted[e.projectile.station].visible = false;
          events.emit('message', { text: `MISIL LANZADO · ${this.sim.targets.find(t => t.id === e.projectile.targetId)?.name}`, duration: 2 });
        }
        events.emit('weapon:launch', { kind: e.projectile.kind });
      } else if (e.type === 'impact') {
        this.explode(e.position, e.destroyed ? 1 : 0.35);
        events.emit('weapon:impact', { position: e.position.toArray() as [number, number, number] });
        if (e.destroyed) {
          events.emit('message', { text: `${e.name} ALCANZADO · ${this.sim.hits}/6`, kind: 'good', duration: 3 });
          if (e.position.y - this.game.env.height(e.position.x, e.position.z) < 30) this.wrecks.push({ position: e.position, time: 0 });
        }
      } else if (e.type === 'flare') this.flareBodies.push({ position: e.position, velocity: e.velocity, age: 0 });
      else if (e.type === 'lock') events.emit('weapon:lock', {});
      else events.emit('message', { text: 'PRÁCTICA COMPLETADA · 6/6 objetivos. Retroceso para repetir.', kind: 'good', duration: 8 });
    }
  }

  private updateShots(puff: boolean): void {
    const live = new Set(this.sim.projectiles.map(p => p.id));
    for (const [id, group] of this.shotGroups) if (!live.has(id)) { group.removeFromParent(); this.shotGroups.delete(id); }
    for (const p of this.sim.projectiles) {
      let group = this.shotGroups.get(p.id);
      if (!group) {
        group = p.kind === 'missile' ? this.missileTemplate.clone() : new Group();
        if (p.kind === 'cannon') { const mesh = new Mesh(this.tracerGeometry, this.tracerMaterial); mesh.rotation.x = Math.PI / 2; group.add(mesh); }
        this.game.scene.add(group); this.shotGroups.set(p.id, group);
      }
      group.position.copy(p.position);
      group.quaternion.setFromUnitVectors(FORWARD, p.velocity.clone().normalize());
      if (p.kind === 'missile' && puff && p.age < 7) {
        // Fill the interval between frames rather than a dotted smoke trail.
        const length = p.velocity.length() / 30;
        const count = Math.ceil(length / 3);
        const direction = p.velocity.clone().normalize();
        for (let i = 0; i < count; i++) {
          const pos = p.position.clone().addScaledVector(direction, -i * length / count);
          this.smoke.emit(pos, new Vector3(0, 0.5, 0), 1.6, 1.6, 5, new Color(0.8, 0.8, 0.76), 0.55);
        }
        this.fire.emit(p.position.clone().addScaledVector(direction, -1.8), direction.clone().multiplyScalar(-40), 0.7, 0.8, 0.12, new Color(10, 4, 0.4), 1);
      }
    }
  }

  private explode(pos: Vector3, scale: number): void {
    for (let i = 0; i < 45; i++) {
      const v = new Vector3(Math.random() - 0.5, Math.random() - 0.1, Math.random() - 0.5).normalize().multiplyScalar((8 + Math.random() * 40) * scale);
      this.fire.emit(pos, v, 3 * scale, 12 * scale, 0.9 + Math.random(), new Color(8, 2.7, 0.4), 1);
      this.smoke.emit(pos, v.clone().multiplyScalar(0.5), 4 * scale, 7 * scale, 6 + Math.random() * 5, new Color(0.15, 0.14, 0.13), 0.8);
      this.sparks.emit(pos, v.clone().multiplyScalar(3), 0.7, 0, 1 + Math.random() * 2, new Color(10, 5, 1), 1, 6);
    }
  }

  private missileModel(): Group {
    const g = new Group();
    const body = new Mesh(new CylinderGeometry(0.13, 0.13, 2.7, 12), this.silver);
    body.rotation.x = Math.PI / 2; g.add(body);
    const nose = new Mesh(new ConeGeometry(0.13, 0.6, 12), this.rubber);
    nose.rotation.x = -Math.PI / 2; nose.position.z = -1.65; g.add(nose);
    for (let i = 0; i < 4; i++) {
      const fin = new Mesh(new BoxGeometry(0.7, 0.025, 0.6), this.silver);
      fin.rotation.z = i * Math.PI / 2; fin.position.z = 0.95; g.add(fin);
    }
    const stripe = new Mesh(new CylinderGeometry(0.135, 0.135, 0.1, 12), this.orange);
    stripe.rotation.x = Math.PI / 2; stripe.position.z = -0.7; g.add(stripe);
    g.traverse(o => { if (o instanceof Mesh) { o.castShadow = true; o.receiveShadow = true; } });
    return g;
  }

  private droneModel(): Group {
    const g = new Group();
    const body = new Mesh(new CylinderGeometry(0.65, 0.35, 8, 10), this.orange);
    body.rotation.x = Math.PI / 2; g.add(body);
    const wing = new Mesh(new BoxGeometry(11, 0.12, 2.4), this.silver); wing.position.z = 0.8; g.add(wing);
    const tail = new Mesh(new BoxGeometry(3.6, 0.12, 1.2), this.orange); tail.position.z = 3.6; g.add(tail);
    const fin = new Mesh(new BoxGeometry(0.14, 1.8, 1.3), this.orange); fin.position.set(0, 0.85, 3.2); g.add(fin);
    const eye = new Mesh(new SphereGeometry(0.4, 8, 6), this.rubber); eye.position.z = -4; g.add(eye);
    g.traverse(o => { if (o instanceof Mesh) { o.castShadow = true; o.receiveShadow = true; } });
    return g;
  }

  private groundModel(t: Target): Group {
    const g = new Group();
    const concrete = worldMaterial(new MeshStandardMaterial({ color: 0xddddcf, roughness: 0.93,
      map: libTexture('ground-concrete_floor_01', 'albedo', [8, 8]),
      normalMap: libTexture('ground-concrete_floor_01', 'normal', [8, 8]) }), { key: 'range-concrete' });
    const pad = new Mesh(new BoxGeometry(46, 0.8, 46), concrete); pad.position.y = -3.8; g.add(pad);
    const box = (w: number, h: number, d: number, x: number, y: number, z: number, mat = this.olive) => {
      const m = new Mesh(new BoxGeometry(w, h, d), mat); m.position.set(x, y, z); g.add(m); return m;
    };
    if (t.id === 3) {
      box(7, 4, 10, 0, 0, 0);
      box(1.5, 11, 1.5, 0, 6, 0);
      const dish = new Mesh(new SphereGeometry(5, 16, 10, 0, Math.PI * 2, 0, Math.PI / 2), this.silver);
      dish.position.y = 12; dish.rotation.x = Math.PI * 0.7; g.add(dish); this.radarDish = dish;
    } else if (t.id === 4) {
      const canvas = worldMaterial(new MeshStandardMaterial({ color: 0x777653, roughness: 0.96,
        map: libTexture('canvas', 'albedo', [3, 2]), normalMap: libTexture('canvas', 'normal', [3, 2]) }), { key: 'range-canvas' });
      const glass = worldMaterial(new MeshStandardMaterial({ color: 0x273e40, metalness: 0.2, roughness: 0.14 }), { key: 'range-glass' });
      box(4.5, 2, 11, 0, -0.8, 0); box(4.2, 2.5, 3, 0, 1.6, -3.5);
      box(4, 0.8, 1.7, 0, 0.35, -5.4); box(4.7, 0.35, 0.4, 0, -0.65, -6.3, this.rubber);
      box(3.5, 1.1, 0.1, 0, 2, -5.05, glass);
      box(0.08, 1.2, 0.15, 0, 2, -5.15, this.olive);
      box(4, 2.8, 6.4, 0, 1.5, 1.55, canvas);
      for (const z of [-1.4, 0, 1.5, 3, 4.5]) box(4.05, 0.1, 0.09, 0, 2.95, z, this.olive);
      for (const x of [-1.65, 1.65]) {
        box(0.65, 0.35, 0.13, x, 0.55, -6.3, this.silver);
        box(0.7, 0.17, 1.5, x * 1.42, -1, -3.3, this.silver);
        box(0.12, 0.8, 0.08, x * 1.47, 1.7, -4.8, this.olive);
        box(0.35, 0.65, 0.2, x * 1.5, 2.1, -4.8, this.rubber);
        box(0.07, 1.2, 1.5, x * 1.28, 1.95, -3.5, glass);
      }
      for (let n = 0; n < 6; n++) box(2.3, 0.07, 0.09, 0, -0.12 + n * 0.12, -6.25, this.rubber);
      for (const x of [-2.4, 2.4]) for (const z of [-3.5, 0, 3.5]) {
        const wheel = new Mesh(new CylinderGeometry(1.15, 1.15, 0.7, 12), this.rubber);
        wheel.rotation.z = Math.PI / 2; wheel.position.set(x, -1.5, z); g.add(wheel);
        const hub = new Mesh(new CylinderGeometry(0.5, 0.5, 0.73, 10), this.silver);
        hub.rotation.z = Math.PI / 2; hub.position.copy(wheel.position); g.add(hub);
      }
    } else {
      const tank = new Mesh(new CylinderGeometry(7, 7, 10, 20), this.silver); tank.position.y = 2; g.add(tank);
      const band = new Mesh(new TorusGeometry(7.1, 0.2, 4, 20), this.orange); band.rotation.x = Math.PI / 2; band.position.y = 3; g.add(band);
      box(0.35, 7, 0.35, -6, 1, -5, this.silver);
    }
    // Range boundary posts and warning stripes add scale without expensive assets.
    for (const x of [-20, 20]) for (const z of [-20, 20]) {
      box(0.3, 3, 0.3, x, -2.2, z, this.orange);
      box(1.8, 0.7, 0.15, x, -0.6, z, this.silver);
    }
    g.traverse(o => { if (o instanceof Mesh) { o.castShadow = true; o.receiveShadow = true; } });
    return g;
  }
}
