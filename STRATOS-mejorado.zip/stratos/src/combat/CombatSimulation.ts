// Arcade training weapons. Independent of rendering, audio and the DOM.
import { Quaternion, Vector3 } from 'three';

export interface CombatPose {
  position: Vector3;
  quaternion: Quaternion;
  velocity: Vector3;
  onGround: boolean;
  destroyed: boolean;
}
export interface Target {
  id: number;
  name: string;
  kind: 'air' | 'ground';
  origin: Vector3;
  position: Vector3;
  velocity: Vector3;
  alive: boolean;
  radius: number;
  health: number;
}
export interface Projectile {
  id: number;
  kind: 'missile' | 'cannon';
  position: Vector3;
  previous: Vector3;
  velocity: Vector3;
  age: number;
  targetId: number | null;
  station: number;
}
export type CombatEvent =
  | { type: 'launch'; projectile: Projectile }
  | { type: 'impact'; position: Vector3; destroyed: boolean; name: string }
  | { type: 'flare'; position: Vector3; velocity: Vector3 }
  | { type: 'lock' }
  | { type: 'complete' };

export const MISSILE_STATIONS = [
  new Vector3(-3.5, -0.5, 0.6), new Vector3(3.5, -0.5, 0.6),
  new Vector3(-2.5, -0.85, 0.3), new Vector3(2.5, -0.85, 0.3),
  new Vector3(-1.8, -1.05, 0.8), new Vector3(1.8, -1.05, 0.8),
];

function sweptDistance(a: Vector3, b: Vector3, p: Vector3): number {
  const d = b.clone().sub(a);
  const t = Math.max(0, Math.min(1, p.clone().sub(a).dot(d) / Math.max(d.lengthSq(), 1e-9)));
  return a.clone().addScaledVector(d, t).distanceTo(p);
}

export class CombatSimulation {
  readonly targets: Target[] = [];
  readonly projectiles: Projectile[] = [];
  readonly pending: CombatEvent[] = [];
  missiles = 6;
  cannonAmmo = 180;
  flares = 24;
  hits = 0;
  selectedId = 0;
  lockProgress = 0;
  time = 0;
  private forward = new Vector3(0, 0, -1);
  private right = new Vector3(1, 0, 0);
  private serial = 0;
  private missileCooldown = 0;
  private cannonCooldown = 0;
  private flareCooldown = 0;
  private complete = false;
  private height: (x: number, z: number) => number;
  constructor(height: (x: number, z: number) => number) { this.height = height; }

  get selected(): Target | undefined { return this.targets.find(t => t.id === this.selectedId && t.alive); }
  get locked(): boolean { return this.lockProgress >= 1; }

  reset(pose: CombatPose): void {
    this.forward.set(0, 0, -1).applyQuaternion(pose.quaternion).setY(0).normalize();
    this.right.set(-this.forward.z, 0, this.forward.x);
    this.targets.length = this.projectiles.length = this.pending.length = 0;
    this.missiles = 6; this.flares = 24; this.cannonAmmo = 180; this.hits = 0;
    this.selectedId = 0; this.lockProgress = this.time = 0;
    this.missileCooldown = this.cannonCooldown = this.flareCooldown = 0;
    this.complete = false;
    for (let i = 0; i < 6; i++) {
      const air = i < 3;
      const p = pose.position.clone().addScaledVector(this.forward, air ? 2200 + i * 480 : 6500 + (i - 3) * 210);
      p.addScaledVector(this.right, air ? (i - 1) * 320 : 2400 + (i - 4) * 220);
      p.y = air ? Math.max(pose.position.y, this.height(p.x, p.z) + 650) + i * 55 : this.height(p.x, p.z) + 4;
      this.targets.push({ id: i, name: air ? `DRON ${i + 1}` : ['RADAR', 'VEHÍCULO', 'DEPÓSITO'][i - 3], kind: air ? 'air' : 'ground',
        origin: p.clone(), position: p, velocity: air ? this.forward.clone().multiplyScalar(125) : new Vector3(),
        alive: true, radius: air ? 16 : 15, health: 1 });
    }
  }

  nextTarget(): void {
    const live = this.targets.filter(t => t.alive);
    if (!live.length) return;
    const index = live.findIndex(t => t.id === this.selectedId);
    this.selectedId = live[(index + 1) % live.length].id;
    this.lockProgress = 0;
  }

  private lineOfSight(a: Vector3, b: Vector3): boolean {
    for (let i = 1; i < 8; i++) {
      const p = a.clone().lerp(b, i / 8);
      if (p.y < this.height(p.x, p.z) + 2) return false;
    }
    return true;
  }

  launch(pose: CombatPose): string | null {
    if (pose.destroyed) return 'Avión destruido. Retroceso para reaparecer.';
    if (pose.onGround) return 'Despega para utilizar el armamento.';
    if (!this.missiles) return 'Sin misiles. Retroceso recarga la práctica.';
    if (!this.locked || !this.selected) return 'Mantén el objetivo delante hasta completar el bloqueo.';
    if (this.missileCooldown > 0) return 'Espera a que se prepare el siguiente misil.';
    const station = 6 - this.missiles;
    const position = MISSILE_STATIONS[station].clone().applyQuaternion(pose.quaternion).add(pose.position);
    const velocity = new Vector3(0, 0, -340).applyQuaternion(pose.quaternion).add(pose.velocity);
    const shot: Projectile = { id: ++this.serial, kind: 'missile', position, previous: position.clone(), velocity,
      age: 0, targetId: this.selected.id, station };
    this.projectiles.push(shot);
    this.pending.push({ type: 'launch', projectile: shot });
    this.missiles--; this.missileCooldown = 0.8;
    return null;
  }

  cannon(pose: CombatPose): void {
    if (pose.onGround || pose.destroyed || !this.cannonAmmo || this.cannonCooldown > 0) return;
    const position = new Vector3(0.45, 0.15, -8).applyQuaternion(pose.quaternion).add(pose.position);
    const velocity = new Vector3(0, 0, -1050).applyQuaternion(pose.quaternion).add(pose.velocity);
    const shot: Projectile = { id: ++this.serial, kind: 'cannon', position, previous: position.clone(), velocity,
      age: 0, targetId: null, station: -1 };
    this.projectiles.push(shot); this.pending.push({ type: 'launch', projectile: shot });
    this.cannonAmmo--; this.cannonCooldown = 0.08;
  }

  deployFlares(pose: CombatPose): boolean {
    if (!this.flares || pose.onGround || pose.destroyed || this.flareCooldown > 0) return false;
    for (const side of [-1, 1]) {
      const position = new Vector3(side * 1.5, -0.5, 4).applyQuaternion(pose.quaternion).add(pose.position);
      const velocity = new Vector3(side * 22, -12, 35).applyQuaternion(pose.quaternion).add(pose.velocity);
      this.pending.push({ type: 'flare', position, velocity });
    }
    this.flares -= 2; this.flareCooldown = 0.6;
    return true;
  }

  step(dt: number, pose: CombatPose): void {
    this.time += dt;
    this.missileCooldown = Math.max(0, this.missileCooldown - dt);
    this.cannonCooldown = Math.max(0, this.cannonCooldown - dt);
    this.flareCooldown = Math.max(0, this.flareCooldown - dt);
    for (const t of this.targets) {
      if (!t.alive || t.kind !== 'air') continue;
      const phase = this.time * 0.16 + t.id;
      const heightBefore = t.position.y;
      t.position.copy(t.origin).addScaledVector(this.forward, this.time * 125).addScaledVector(this.right, Math.sin(phase) * 100 - Math.sin(t.id) * 100);
      t.position.y = Math.max(t.origin.y + Math.sin(this.time * 0.2 + t.id) * 35, this.height(t.position.x, t.position.z) + 150);
      t.velocity.copy(this.forward).multiplyScalar(125).addScaledVector(this.right, Math.cos(phase) * 16);
      t.velocity.y = (t.position.y - heightBefore) / dt;
    }
    const selected = this.selected;
    const wasLocked = this.locked;
    if (selected && !pose.destroyed && !pose.onGround) {
      const direction = selected.position.clone().sub(pose.position);
      const distance = direction.length();
      const fwd = new Vector3(0, 0, -1).applyQuaternion(pose.quaternion);
      const available = distance > 100 && distance < 8000 && fwd.dot(direction.normalize()) > 0.82 && this.lineOfSight(pose.position, selected.position);
      this.lockProgress = available ? Math.min(1, this.lockProgress + dt / 1.1) : 0;
    } else this.lockProgress = 0;
    if (this.locked && !wasLocked) this.pending.push({ type: 'lock' });

    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const p = this.projectiles[i];
      p.age += dt; p.previous.copy(p.position);
      const target = this.targets.find(t => t.id === p.targetId && t.alive);
      if (p.kind === 'missile' && target && p.age > 0.18) {
        const desired = target.position.clone().addScaledVector(target.velocity, Math.min(0.8, p.position.distanceTo(target.position) / 700)).sub(p.position).normalize();
        const speed = Math.min(760, p.velocity.length() + 160 * dt);
        p.velocity.normalize().lerp(desired, 1 - Math.exp(-3.2 * dt)).normalize().multiplyScalar(speed);
      } else if (p.kind === 'cannon' || p.age > 7) p.velocity.y -= 9.8 * dt;
      p.position.addScaledVector(p.velocity, dt);
      let hit = false;
      if (p.kind === 'cannon' || p.age > 0.2) for (const t of this.targets) {
        if (!t.alive || sweptDistance(p.previous, p.position, t.position) > (p.kind === 'missile' ? t.radius + 10 : t.radius)) continue;
        t.health -= p.kind === 'missile' ? 1 : 0.25;
        const destroyed = t.health <= 0;
        if (destroyed) { t.alive = false; this.hits++; }
        this.pending.push({ type: 'impact', position: t.position.clone(), destroyed, name: t.name });
        if (destroyed && t.id === this.selectedId) this.nextTarget();
        hit = true; break;
      }
      const ground = p.position.y <= this.height(p.position.x, p.position.z);
      if (ground && !hit && p.kind === 'missile') this.pending.push({ type: 'impact', position: p.position.clone(), destroyed: false, name: 'TERRENO' });
      if (hit || ground || p.age > (p.kind === 'missile' ? 18 : 2.5)) this.projectiles.splice(i, 1);
    }
    if (!this.complete && this.targets.length > 0 && this.targets.every(t => !t.alive)) {
      this.complete = true; this.pending.push({ type: 'complete' });
    }
  }
}
