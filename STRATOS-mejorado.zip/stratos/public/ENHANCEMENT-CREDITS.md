# Free resources added to STRATOS — 7 October 2026

All assets below are distributed under CC0. Downloaded files are served locally;
the running game does not depend on third-party asset servers or paid accounts.
The game's existing GPL-2.0-or-later license still applies to its code and F-16 model.

## Poly Haven scanned materials

Downloaded through the official API with User-Agent `StratosLocalAssetImport/1.0`.
Each original JPG was verified against the API's MD5 checksum. Resolution: 1K.
All three materials include diffuse, OpenGL normal and roughness maps.

| Material | Official source | Used in game |
| --- | --- | --- |
| Asphalt Floor | https://polyhaven.com/a/asphalt_floor | Runway and taxiway surface detail |
| Concrete Floor 01 | https://polyhaven.com/a/concrete_floor_01 | Apron, practice range platforms |
| Grass Path 2 | https://polyhaven.com/a/grass_path_2 | Close-range ground colour, normals and roughness |

License: https://polyhaven.com/license

## Kenney Particle Pack

Source: https://kenney.nl/assets/particle-pack

`PNG (Transparent)/smoke_01.png` → `fx/smoke.png` (missile trails, smoke, impact clouds).
`PNG (Transparent)/fire_01.png` → `fx/fire.png` (rocket exhaust, explosions, burning wreckage, practice flares).
Original license included in `fx/KENNEY-LICENSE.txt`.

## JangaFX Cloud Pack

Official source: https://jangafx.com/software/embergen/download/free-vdb-animations
Cloud Pack download linked by the official page:
https://www.mediafire.com/file/879onggscuon7ew/CloudPackVDB.zip/file

`cloud_01_variant_0000.vdb` and `cloud_03_variant_0000.vdb` were converted with
Blender's OpenVDB module (`scripts/convert-clouds.py`) to two 96³, Y-up, uint8
density volumes. The runtime ray marcher samples these volumes as 3D textures,
varies their orientation, blends them with procedural cloud weather and advects
them with the wind. CPU in-cloud effects sample the same imported density.
Total density data: 1,769,472 bytes. Source and converted SHA-256 checksums,
bounds and density normalization are recorded in `clouds/manifest.json`.
Original CC0 license and pack README: `clouds/JANGAFX-LICENSE.txt` and
`clouds/JANGAFX-README.txt`. The full VDB download is not required at runtime.

The new missile, drone, radar, truck and tank geometry is authored in code for
this game. Weapon movement is an arcade simulation; practice flares are visual
effects, and there are no hostile aircraft or incoming-missile countermeasures.
