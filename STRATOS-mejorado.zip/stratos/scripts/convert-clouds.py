"""Bake CC0 JangaFX VDB density grids into compact browser-ready 3D textures.

Run with Blender's bundled openvdb/numpy (no add-on required):
blender --background --python scripts/convert-clouds.py -- <CloudPackVDB-dir> <public/clouds-dir>
The source pack uses Z-up; STRATOS uses Y-up. Output is a 96-cube, one byte
per voxel, X-fastest, preserving the source cloud's aspect ratio.
"""
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
import openvdb

source, destination = map(Path, sys.argv[sys.argv.index('--') + 1:][:2])
destination.mkdir(parents=True, exist_ok=True)
size = 96
records = []
for number in (1, 3):
    filename = f'cloud_{number:02d}_variant_0000.vdb'
    grids, _metadata = openvdb.readAll(str(source / filename))
    grid = next(g for g in grids if g.name == 'density')
    low, high = map(np.array, grid.evalActiveVoxelBoundingBox())
    extent = high - low + 1
    dense = np.zeros(tuple(extent), dtype=np.float32)
    grid.copyToArray(dense, ijk=tuple(int(v) for v in low))
    positive = dense[dense > 0]
    scale = float(np.percentile(positive, 98))
    # Bake a cube with a small transparent border; bottom-align the cloud.
    span = int(max(extent) + 12)
    start = (extent - span) / 2
    start[2] = -6
    coords = [np.linspace(start[i], start[i] + span - 1, size) for i in range(3)]
    # Output Z,Y,X array: WebGL stores X fastest; source Z becomes output Y.
    sx, sz, sy = np.meshgrid(coords[0], coords[1], coords[2], indexing='ij')
    bases = [np.floor(c).astype(np.int32) for c in (sx, sz, sy)]
    fractions = [c - b for c, b in zip((sx, sz, sy), bases)]
    sampled = np.zeros((size, size, size), dtype=np.float32)
    for ox in (0, 1):
        for oy in (0, 1):
            for oz in (0, 1):
                offsets = (ox, oy, oz)
                idx = [b + o for b, o in zip(bases, offsets)]
                valid = np.ones(sampled.shape, dtype=bool)
                weight = np.ones(sampled.shape, dtype=np.float32)
                for axis in range(3):
                    valid &= (idx[axis] >= 0) & (idx[axis] < extent[axis])
                    weight *= fractions[axis] if offsets[axis] else 1 - fractions[axis]
                    idx[axis] = np.clip(idx[axis], 0, extent[axis] - 1)
                sampled += dense[tuple(idx)] * weight * valid
    data = np.rint(np.clip(sampled / max(scale, 1e-6), 0, 1) * 255).astype(np.uint8)
    # Original array axes are source X,Y,Z; reorder to output Z,Y,X = source Y,Z,X.
    binary = data.transpose(1, 2, 0).copy().tobytes()
    out = f'jangafx-cloud-{number:02d}.bin'
    (destination / out).write_bytes(binary)
    record = {'file': out, 'size': size, 'source': filename, 'sourceSha256': hashlib.sha256((source / filename).read_bytes()).hexdigest(),
              'sha256': hashlib.sha256(binary).hexdigest(), 'occupiedVoxels': int(np.count_nonzero(data)), 'normalization': scale,
              'sourceBounds': [low.tolist(), high.tolist()], 'sourceAxis': 'Z-up', 'outputAxis': 'Y-up', 'license': 'CC0'}
    records.append(record)
    print(json.dumps(record), flush=True)
(destination / 'manifest.json').write_text(json.dumps({'format': 'uint8 density, X fastest', 'source': 'JangaFX Cloud Pack', 'volumes': records}, indent=2), encoding='utf-8')
